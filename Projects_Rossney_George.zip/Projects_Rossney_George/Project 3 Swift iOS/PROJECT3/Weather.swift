//
//  Weather.swift
//  PROJECT3
//
//  Created by George Rossney on 12/14/16.
//  Copyright © 2016 George Rossney. All rights reserved.
//

import Foundation

struct Weather {
    //criteria for weather/wind checker
    var city: String?
    var chill: String?
    var direction: String?
    var speed: String? 


}
