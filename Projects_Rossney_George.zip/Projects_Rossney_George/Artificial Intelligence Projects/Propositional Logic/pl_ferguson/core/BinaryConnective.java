package pl.core;

public enum BinaryConnective {
	
	AND, OR, IMPLIES, IFF

}
