package pl.core;

abstract public class CompoundSentence implements Sentence {

}
