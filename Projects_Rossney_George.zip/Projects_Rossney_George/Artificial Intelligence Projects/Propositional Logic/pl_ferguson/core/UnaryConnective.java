package pl.core;

public enum UnaryConnective {
	NOT
}
