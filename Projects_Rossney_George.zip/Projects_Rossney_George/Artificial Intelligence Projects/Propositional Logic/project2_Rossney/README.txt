
George Rossney
CSC 242
Project 2: Automated Reasoning
Date submitted: 3/16/16


Collaboration: I did not collaborate with anyone on any part of this assignment. I did not use any additional sources besides the AIMA textbook, Prof. Ferguson’s lecture slides, and his sample propositional logic code. 


Language: I used Java as my language for coding this project. I wrote, compiled, and ran each Java file in the Eclipse Mars IDE for Mac OS X. For the files that require user input, input is entered thru a console scanner. I did not use any text files for input or output. 


Included files:
README.txt (this file)
WriteUP_Rossney.pdf 
PropLogic.java
DPLL.java 
ModusPonens.java
WumpusWorld.java
HornClauses.java 
