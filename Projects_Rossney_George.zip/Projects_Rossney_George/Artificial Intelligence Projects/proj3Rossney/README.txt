George Rossney
CSC 242
Project 3: Inference - Bayesian Networks 
Date submitted: 4/15/16


Collaboration: I did not collaborate with anyone on any part of this assignment. I have included links and described the sources I used on the last page of my WriteUp pdf file.


Language and Testing: I used Java as my language for coding this project. I wrote, compiled, and ran each Java file in the Eclipse Mars IDE for Mac OS X. For testing, I used the given command line instruction included in the project 3 PDF. I used the give example files to test different sample sizes on each inference algorithm. 


Text files:
README.txt (this file)
WriteUP_Rossney.pdf 

All Java files are contained in my Proj3Rossney package folder:
BN.java
BNnode.java
CPT.java (I started with Prof. Ferguson’s file)
EnumerationQuery.java - Part 1 
Inference.java
JointDistTree.java
LikelihoodWeighting.java - Part 2 
Node.java
RandomVariable.java
RejectionSampling.java - Part 2 
XMLBIFParser.java (I started with Prof. Ferguson’s file)