/* 
 George Rossney 
 Project 4: Street Mapping 
 Course: CSC 172
 Lab TA: Pauline Chen 
 Session: T/Th 4:50-6:05pm 
*/

//interface for graph adjacency list
public interface AdjList {
	int begin();
	int next();
	boolean end(); 
	
}
