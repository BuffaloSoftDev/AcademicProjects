/*
George Rossney 
Project 3: Point Location  
CSC 172
Lab TA: Pauline Chen 
Session: T/Th 4:50-6:05pm 
*/
package pointlocationpkg;


//making the constructor for point a separate class,
// since it gets used so much 
public class Point {
	
	double a,b; 
	
	public Point(double a, double b){
		this.a = a;
		this.b = b;
	}
}//closing public class point 
