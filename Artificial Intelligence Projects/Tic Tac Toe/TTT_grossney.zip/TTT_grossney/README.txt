

George Rossney 
CSC 242
Project 1: Tic Tac Toe 
Date submitted: 2/15/16

README:

Collaboration: I did not collaborate with anyone on this project and all work  is my own. I only used Professor Ferguson’s slides and our textbook, Artificial Intelligence: A Modern Approach as sources for completing this project. 

Tournament: Due to glitches and errors with the Nine-Board version of my Tic Tac Toe game, I would not like to be entered into the tournament. 

Submission: As stated in my write-up pdf, I implemented two different versions of the classic Tic Tac Toe game in Java. My submitted zip file includes two project folders, one for each game version, with three java files within each folder. 

Known issue: I am confident on my 3x3 version of Tic Tac Toe, but my Nine-Board version is flawed. After being unsuccessful in making a game board of a mini 3x3 board in each spot on the large 3x3 board, I modified my game to make one large 9x9 board. The 9x9 version runs without Java compilation or execution errors, but has bugs while running/playing the game. 

Included files:
README (this file)
WriteUp_Rossney.pdf (written report)
In TicTacToe_Grossney folder:
- Main.java
- Node.java
- TicTacToe.java 
In NineBoardTTT_Grossney folder:
- NineBoardMain.java
- NineBoard Node.java
- NineBoardTTT.java 

Running the game: To run the either version of the game, run one of the files included in each package folder. The program will prompt the user for input and will output to the console. I wrote, compiled, and tested all files in the Eclipse Mars IDE for Mac. 